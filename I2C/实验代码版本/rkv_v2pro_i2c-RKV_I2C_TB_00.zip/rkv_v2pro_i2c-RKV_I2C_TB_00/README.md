# rkv_v2pro_i2c
RockerIC verification V2pro virtual project
